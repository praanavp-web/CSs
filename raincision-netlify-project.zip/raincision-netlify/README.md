# Raincision — Netlify + Supabase starter

This package adapts your self-contained `raincision_single_file.html` into a deployable Netlify project and adds a serverless API backed by Supabase PostgreSQL.

## What's included
- `index.html` — your supplied single-file frontend (embedded CSS/JavaScript retained)
- `netlify/functions/api.js` — API routes for status, mission logs, inventory, feasibility requests
- `netlify.toml` — Netlify build and `/api/*` routing
- `supabase-schema.sql` — database tables and demo inventory seed rows

## 1. Create the database
1. Create a project at https://supabase.com/
2. Open **SQL Editor** in the Supabase dashboard.
3. Open `supabase-schema.sql`, copy its full contents, and run it.
4. In **Project Settings → API** (or API Keys), copy the Project URL and the `service_role`/secret server key. Never put that key in `index.html` or any browser-side JavaScript.

## 2. Deploy to Netlify
1. Extract this ZIP.
2. Push the contents to a new GitHub repository, or import the extracted project using a supported Netlify deployment workflow.
3. In Netlify, create/import the site and set these environment variables in **Site configuration → Environment variables**:
   - `SUPABASE_URL` = your Supabase project URL
   - `SUPABASE_SERVICE_ROLE_KEY` = your server-side service role key
4. Ensure the variables are available to **Functions** and trigger a new deploy.
5. Netlify should publish the repository root and deploy `netlify/functions/api.js`.

## 3. Test the live site
Replace `YOUR-SITE.netlify.app` with your actual site hostname:
- `https://YOUR-SITE.netlify.app/api/status`
- `https://YOUR-SITE.netlify.app/api/logs`
- `https://YOUR-SITE.netlify.app/api/inventory`
- `https://YOUR-SITE.netlify.app/api/feasibility`

Submit a feasibility request and confirm that it appears in Supabase's `feasibility_requests` table. Add a test mission through the quick mission modal and check `mission_logs`.

## 4. Run locally (optional)
Install Node.js, then from this folder:
```bash
npm install
npx netlify-cli dev
```
Set environment variables in a local `.env` file or your shell. Do not commit `.env` to GitHub. If using a local `.env`, add it to `.gitignore`.

## Important demo notes
- The project displays illustrative telemetry/KPIs and simulated weather/mission information. They are not live radar, aircraft, drone, precipitation, or scientifically verified cloud-seeding results.
- Feasibility submissions are persisted, but projected yield and ROI are placeholders until you implement a real, validated model.
- The service-role key is highly privileged. Keep it only in Netlify server-side environment variables. For a public production app, add rate limiting, spam protection, validation, and appropriate access controls before collecting real personal data.
