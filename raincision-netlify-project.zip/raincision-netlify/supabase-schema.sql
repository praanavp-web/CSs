-- Run this entire script in Supabase Dashboard > SQL Editor.
-- This schema is for a student/demo project. Mission telemetry and yields shown in the UI
-- are illustrative unless populated with verified real-world data.

create extension if not exists pgcrypto;

create table if not exists public.mission_logs (
  id uuid primary key default gen_random_uuid(),
  mission_id text not null unique,
  vector text not null check (vector in ('aircraft','drone','ground')),
  vector_name text not null,
  chemical_agent text not null,
  flares_count integer not null default 1 check (flares_count between 1 and 24),
  discharged_qty integer not null default 1,
  coordinates text not null,
  cloud_base_top text not null,
  efficacy_rating text not null default 'PENDING REVIEW',
  created_at timestamptz not null default now()
);

create table if not exists public.feasibility_requests (
  id uuid primary key default gen_random_uuid(),
  tracking_id text not null unique,
  contact_name text not null,
  email text not null,
  organization text not null,
  objective text,
  basin_coords text,
  notes text,
  status text not null default 'RECEIVED',
  projected_yield_af numeric not null default 0,
  estimated_roi text not null default 'Requires feasibility assessment',
  created_at timestamptz not null default now()
);

create table if not exists public.inventory (
  id uuid primary key default gen_random_uuid(),
  item_key text not null unique,
  item_name text not null,
  current_stock numeric not null default 0,
  unit text not null,
  updated_at timestamptz not null default now()
);

insert into public.inventory (item_key, item_name, current_stock, unit)
values
 ('agi_burn_flares', 'AgI burn flares', 420, 'Units'),
 ('ejectable_flares', 'Ejectable flares', 180, 'Units'),
 ('acetone_solution', 'Acetone solution', 85, 'Liters'),
 ('hygroscopic_salts', 'Hygroscopic salts', 260, 'kg')
on conflict (item_key) do nothing;

-- Do not expose tables directly to anonymous users. The Netlify function uses the
-- server-side service role key, which must only exist in Netlify environment variables.
alter table public.mission_logs enable row level security;
alter table public.feasibility_requests enable row level security;
alter table public.inventory enable row level security;
