const JSON_HEADERS = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store"
};

function response(statusCode, body) {
  return { statusCode, headers: JSON_HEADERS, body: JSON.stringify(body) };
}

function env() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Server configuration is missing Supabase environment variables.");
  return { url: url.replace(/\/$/, ""), key };
}

async function db(path, options = {}) {
  const { url, key } = env();
  const res = await fetch(`${url}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: options.method === "POST" ? "return=representation" : "count=exact",
      ...(options.headers || {})
    }
  });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { message: text }; }
  if (!res.ok) {
    const err = new Error(data?.message || data?.hint || `Database request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

function safeString(value, max = 500) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

exports.handler = async (event) => {
  const method = event.httpMethod;
  const path = (event.path || "").replace(/^.*\/api\/?/, "").replace(/\/$/, "");
  try {
    if (method === "OPTIONS") return response(204, {});
    if (path === "status" && method === "GET") {
      const rows = await db("mission_logs?select=id&limit=1");
      const requests = await db("feasibility_requests?select=id&limit=1");
      return response(200, {
        success: true,
        database: "Supabase PostgreSQL",
        connected: true,
        hydrological_yield_ytd_af: 142850,
        checks: { mission_logs: Array.isArray(rows), feasibility_requests: Array.isArray(requests) }
      });
    }

    if (path === "logs" && method === "GET") {
      const logs = await db("mission_logs?select=*&order=created_at.desc&limit=100");
      return response(200, { logs: logs.map(row => ({
        ...row,
        timestamp: row.timestamp || new Date(row.created_at).toLocaleString(),
        discharged_qty: row.discharged_qty ?? row.flares_count
      })) });
    }

    if (path === "logs" && method === "POST") {
      const body = JSON.parse(event.body || "{}");
      const vector = ["aircraft", "drone", "ground"].includes(body.vector) ? body.vector : "drone";
      const flares = Math.max(1, Math.min(24, Number.parseInt(body.flares_count, 10) || 4));
      const row = {
        mission_id: `RC-${Date.now().toString(36).toUpperCase()}`,
        vector,
        vector_name: safeString(body.vector_name, 120) || vector,
        chemical_agent: safeString(body.chemical_agent, 120) || "Not specified",
        flares_count: flares,
        discharged_qty: flares,
        coordinates: safeString(body.coordinates, 120) || "Not specified",
        cloud_base_top: safeString(body.cloud_base_top, 120) || "Not recorded",
        efficacy_rating: "PENDING REVIEW"
      };
      const saved = await db("mission_logs", { method: "POST", body: JSON.stringify(row) });
      return response(201, { success: true, mission_id: saved?.[0]?.mission_id || row.mission_id });
    }

    if (path === "inventory" && method === "GET") {
      const inventory = await db("inventory?select=*&order=item_key.asc");
      return response(200, { inventory });
    }

    if (path === "feasibility" && method === "GET") {
      const requests = await db("feasibility_requests?select=*&order=created_at.desc&limit=30");
      return response(200, { requests });
    }

    if (path === "feasibility" && method === "POST") {
      const body = JSON.parse(event.body || "{}");
      const contact_name = safeString(body.contact_name, 120);
      const email = safeString(body.email, 254);
      const organization = safeString(body.organization, 160);
      if (!contact_name || !email || !organization || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return response(400, { error: "Please provide a valid name, email, and organization." });
      }
      const row = {
        tracking_id: `RF-${Date.now().toString(36).toUpperCase()}`,
        contact_name,
        email,
        organization,
        objective: safeString(body.objective, 160),
        basin_coords: safeString(body.basin_coords, 200),
        notes: safeString(body.notes, 3000),
        status: "RECEIVED",
        projected_yield_af: 0,
        estimated_roi: "Requires feasibility assessment"
      };
      const saved = await db("feasibility_requests", { method: "POST", body: JSON.stringify(row) });
      return response(201, saved?.[0] || row);
    }

    return response(404, { error: "API route not found." });
  } catch (error) {
    console.error("Raincision API error:", error);
    return response(error.status || 500, {
      error: error.status && error.status < 500 ? error.message : "Backend unavailable. Check Supabase configuration and table setup."
    });
  }
};
